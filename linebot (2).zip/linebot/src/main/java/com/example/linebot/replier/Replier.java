package com.example.linebot.replier;
import com.linecorp.bot.model.message.Message;

public interface Replier {

    Message reply();
}
